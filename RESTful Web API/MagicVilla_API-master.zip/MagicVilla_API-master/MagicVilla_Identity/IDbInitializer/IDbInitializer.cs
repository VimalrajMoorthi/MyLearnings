﻿namespace MagicVilla_Identity.IDbInitializer
{
    public interface IDbInitializer
    {
        public void Initialize();
    }
}
